//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por ListasLigadasPIA.rc
//
#define IDC_MYICON                      2
#define IDD_LISTASLIGADASPIA_DIALOG     102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_LISTASLIGADASPIA            107
#define IDI_SMALL                       108
#define IDC_LISTASLIGADASPIA            109
#define IDR_MAINFRAME                   128
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDD_DOCTOR                      133
#define IDD_LOGIN                       134
#define IDC_DATETIMEPICKER1             1002
#define IDC_DATETIMEPICKER2             1003
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1005
#define IDC_COMBO1                      1006
#define IDC_EDIT3                       1007
#define IDC_EDIT4                       1008
#define IDC_EDIT5                       1009
#define IDC_RADIO1                      1010
#define IDC_RADIO2                      1011
#define IDC_RADIO3                      1012
#define IDC_SAVE                        1013
#define IDC_CANCEL                      1017
#define IDC_LIST1                       1018
#define IDC_DELETE                      1019
#define IDC_PREV                        1020
#define IDC_EDIT                        1021
#define IDC_RETURN                      1022
#define IDC_SHOW                        1023
#define IDC_USERNAME                    1024
#define IDC_CEDULA                      1025
#define IDC_CLAVE                       1026
#define IDC_PASSWORD                    1027
#define IDC_SAVEUSER                    1028
#define IDC_BACK                        1029
#define IDC_LOGINCLAVE                  1030
#define IDC_LOGINPASSWORD               1031
#define IDC_LOGIN                       1032
#define IDC_REGRESAR                    1033
#define ID_ARCHIVO_AGENDA               32771
#define ID_ARCHIVO_A32772               32772
#define ID_ARCHIVO_CITA                 32773
#define ID_ARCHIVO_USUARIO              32774
#define ID_ARCHIVO_INICIARSESION        32775
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1034
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
