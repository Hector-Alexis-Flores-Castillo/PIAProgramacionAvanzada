// ListasLigadasPIA.cpp : Define el punto de entrada de la aplicación.
//

#include "framework.h"
#include "ListasLigadasPIA.h"
#include <fstream>
#include <string>
#include <CommCtrl.h>
using namespace std;

#define MAX_LOADSTRING 100

//Estructura de nodos de lista de citas.
struct nCita {
    wchar_t nombreCliente[100] = {L""}, nombreMascota[100] = { L"" }, motivo[200] = { L"" };
    wchar_t charfecha[50] = { L"" }, charhora[50] = { L"" }, charespecie[100] = { L"" };
	wchar_t telefono[50] = { L"" }, costo[50] = { L"" };
    SYSTEMTIME fecha, hora;
    int estatus = 0, especie = 0, NumCita = 0;
    nCita* Ant;
    nCita* Sig;
};

//Datos del doctor. Clave y contraseña vienen con valores default.
wchar_t nDoctor[100] = { L"doctor" }, cDoctor[100] = { L"1234" }, cUsuario[100] = { L"1234" }, pass[100] = { L"1234" };

//Variables globales.
bool login = FALSE;
int ItemData;
nCita* inicio = NULL;	//Lista de citas.
int CountCitas = 0;	//Contador para asignarle un número a cada cita.
char fileCitas[] = "AgendaCitas.dat";

// Variables globales:
HINSTANCE hInst;                                // instancia actual
WCHAR szTitle[MAX_LOADSTRING];                  // Texto de la barra de título
WCHAR szWindowClass[MAX_LOADSTRING];            // nombre de clase de la ventana principal

// Declaraciones de funciones adelantadas incluidas en este módulo de código:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Agenda(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Cita(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	EditarCita(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Doctor(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Login(HWND, UINT, WPARAM, LPARAM);

//Prototipos de función.
void NuevaCita(nCita*&, HWND);	//Guardar cita nueva.
void MostrarEditarCita(nCita*&, HWND, int);	//Muestra una cita que ya exista para editarla, necesita número de cita.
void LeerEditarCita(nCita*&, HWND, int); //Se debería utilizar después de la anterior, para leer los cambios.
void ListBoxCitas(nCita*&, HWND);	//Imprime todas las citas en la list box de la agenda.
void VistaPreviaCita(nCita*&, HWND, int);	//Imprime los datos de la cita seleccionada en la agenda.
void EliminarCita(nCita*&, HWND, int);	//Elimina la cita con el número de cita.
void ImprimirDoctor(HWND);	//Muestra los datos del doctor.
void LeerDoctor(HWND);	//Guarda y reescribe los datos del doctor.
void IniciarSesion(HWND);	//Comprueba que el inicio de sesion sea valido.

//Prototipos de archivos binarios.
void ArchivoCitas(char*);
void readCitas(char*);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Colocar código aquí.

    // Inicializar cadenas globales
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_LISTASLIGADASPIA, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Realizar la inicialización de la aplicación:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_LISTASLIGADASPIA));

	//Leer archivos binarios.
	readCitas(fileCitas);

    MSG msg;

    // Bucle principal de mensajes:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

	//Guardar archivos binarios.
	ArchivoCitas(fileCitas);

    return (int) msg.wParam;
}



//
//  FUNCIÓN: MyRegisterClass()
//
//  PROPÓSITO: Registra la clase de ventana.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_LISTASLIGADASPIA));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_LISTASLIGADASPIA);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCIÓN: InitInstance(HINSTANCE, int)
//
//   PROPÓSITO: Guarda el identificador de instancia y crea la ventana principal
//
//   COMENTARIOS:
//
//        En esta función, se guarda el identificador de instancia en una variable común y
//        se crea y muestra la ventana principal del programa.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Almacenar identificador de instancia en una variable global

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCIÓN: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PROPÓSITO: Procesa mensajes de la ventana principal.
//
//  WM_COMMAND  - procesar el menú de aplicaciones
//  WM_PAINT    - Pintar la ventana principal
//  WM_DESTROY  - publicar un mensaje de salida y volver
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Analizar las selecciones de menú:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
			case ID_ARCHIVO_AGENDA:
				if (login == FALSE) {
					MessageBox(hWnd, L"Debe iniciar sesion.", L"Aviso", MB_ICONERROR);
				}
				if (login == TRUE) {
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG3), hWnd, Agenda);
				}
				break;
			case ID_ARCHIVO_CITA:
				if (login == FALSE) {
					MessageBox(hWnd, L"Debe iniciar sesion.", L"Aviso", MB_ICONERROR);
				}
				if (login == TRUE) {
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG2), hWnd, Cita);
				}
				break;
			case ID_ARCHIVO_USUARIO:
				if (login == FALSE) {
					MessageBox(hWnd, L"Debe iniciar sesion.", L"Aviso", MB_ICONERROR);
				}
				if (login == TRUE) {
					DialogBox(hInst, MAKEINTRESOURCE(IDD_DOCTOR), hWnd, Doctor);
				}
				break;
			case ID_ARCHIVO_INICIARSESION:
				DialogBox(hInst, MAKEINTRESOURCE(IDD_LOGIN), hWnd, Login);
				break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: Agregar cualquier código de dibujo que use hDC aquí...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Controlador de mensajes del cuadro Acerca de.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Agenda(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		ListBoxCitas(inicio, hDlg);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_RETURN)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_EDIT)
		{
			int ListPos = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETCURSEL, 0, 0);
			ItemData = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETITEMDATA, ListPos, NULL);
			if (ListPos != -1) {
				DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG2), hDlg, EditarCita);
				SendDlgItemMessage(hDlg, IDC_LIST1, LB_RESETCONTENT, 0, 0);
				SendDlgItemMessage(hDlg, IDC_PREV, WM_SETTEXT, NULL, (LPARAM)L"");
				ListBoxCitas(inicio, hDlg);
			}
			
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_SHOW)
		{
			int ListPos = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETCURSEL, 0, 0);
			ItemData = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETITEMDATA, ListPos, NULL);
			if (ListPos != -1) {
				VistaPreviaCita(inicio, hDlg, ItemData);
			}
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_DELETE)
		{
			int ListPos = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETCURSEL, 0, 0);
			ItemData = SendDlgItemMessage(hDlg, IDC_LIST1, LB_GETITEMDATA, ListPos, NULL);
			if (ListPos != -1) {
				EliminarCita(inicio, hDlg, ItemData);
				SendDlgItemMessage(hDlg, IDC_LIST1, LB_RESETCONTENT, 0, 0);
				SendDlgItemMessage(hDlg, IDC_PREV, WM_SETTEXT, NULL, (LPARAM)L"");
				ListBoxCitas(inicio, hDlg);
			}
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Cita(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL,(LPARAM)L"Perro");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Gato");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Reptil");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Ave");
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_CANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_SAVE)
		{
			NuevaCita(inicio, hDlg);
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK EditarCita(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Perro");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Gato");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Reptil");
		SendDlgItemMessage(hDlg, IDC_COMBO1, CB_ADDSTRING, NULL, (LPARAM)L"Ave");
		MostrarEditarCita(inicio, hDlg, ItemData);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_CANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_SAVE)
		{
			LeerEditarCita(inicio, hDlg, ItemData);
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Doctor(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		ImprimirDoctor(hDlg);
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_BACK)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_SAVEUSER)
		{
			LeerDoctor(hDlg);
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Login(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDC_REGRESAR)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		if (LOWORD(wParam) == IDC_LOGIN)
		{
			IniciarSesion(hDlg);
			if(login == FALSE) {
				MessageBox(hDlg, L"Clave o contrasena invalidos.", L"Aviso", MB_ICONERROR);
			}
			if (login == TRUE) {
				MessageBox(hDlg, L"Bienvenido.", L"Aviso", MB_OK);
				EndDialog(hDlg, LOWORD(wParam));
			}
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

//Esta función usa la ventana de agendar cita.
void NuevaCita(nCita*& inicio, HWND hwnd) {
	//Handlers (cambiar IDs).
	HWND hFecha = GetDlgItem(hwnd, IDC_DATETIMEPICKER1);
	HWND hHora = GetDlgItem(hwnd, IDC_DATETIMEPICKER2);
	HWND hNameC = GetDlgItem(hwnd, IDC_EDIT1);
	HWND hTel = GetDlgItem(hwnd, IDC_EDIT2);
	HWND hEspecie = GetDlgItem(hwnd, IDC_COMBO1);
	HWND hNameM = GetDlgItem(hwnd, IDC_EDIT3);
	HWND hMotivo = GetDlgItem(hwnd, IDC_EDIT4);
	HWND hCosto = GetDlgItem(hwnd, IDC_EDIT5);

	//Crear nodo y enviar al final.
	nCita* final = inicio;
	nCita* nuevo = new nCita();
	while (final != NULL && final->Sig != NULL) {
		final = final->Sig;
	}
	if (final != NULL) {
		final->Sig = nuevo;
	}
	else {
		inicio = nuevo;
	}
	nuevo->Ant = final;

	//Auxiliares.
	int Length;

	//Guardar datos en nodo.
	//(Cambiar IDs de datetimepickers).
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER1, DTM_GETSYSTEMTIME, 0, (LPARAM)&nuevo->fecha);
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER2, DTM_GETSYSTEMTIME, 0, (LPARAM)&nuevo->hora);

	Length = GetWindowTextLength(hFecha);
	GetWindowText(hFecha, nuevo->charfecha, ++Length);
	Length = GetWindowTextLength(hHora);
	GetWindowText(hHora, nuevo->charhora, ++Length);
	Length = GetWindowTextLength(hNameC);
	GetWindowText(hNameC, nuevo->nombreCliente, ++Length);
	Length = GetWindowTextLength(hTel);
	GetWindowText(hTel, nuevo->telefono, ++Length);

	//(Cambiar ID de combo box).
	nuevo->especie = SendDlgItemMessage(hwnd, IDC_COMBO1, CB_GETCURSEL, 0, 0);

	Length = GetWindowTextLength(hEspecie);
	GetWindowText(hEspecie, nuevo->charespecie, ++Length);
	Length = GetWindowTextLength(hNameM);
	GetWindowText(hNameM, nuevo->nombreMascota, ++Length);
	Length = GetWindowTextLength(hMotivo);
	GetWindowText(hMotivo, nuevo->motivo, ++Length);
	Length = GetWindowTextLength(hCosto);
	GetWindowText(hCosto, nuevo->costo, ++Length);

	//(Cambiar IDs de radios).
	if (IsDlgButtonChecked(hwnd, IDC_RADIO1) == BST_CHECKED) {
		nuevo->estatus = 1;
	}
	if (IsDlgButtonChecked(hwnd, IDC_RADIO2) == BST_CHECKED) {
		nuevo->estatus = 2;
	}
	if (IsDlgButtonChecked(hwnd, IDC_RADIO3) == BST_CHECKED) {
		nuevo->estatus = 3;
	}

	//Asignar número de cita único.
	nuevo->NumCita = CountCitas;
	CountCitas++;
}

//Usa ventana de agendar cita.
void MostrarEditarCita(nCita*& inicio, HWND hwnd, int NumCita) {
	//Buscar nodo.
	nCita* aux = inicio;
	if (inicio == NULL) {
		MessageBox(hwnd, L"La agenda esta vacia", L"Aviso", MB_ICONERROR);
		return;
	}
	while (aux->NumCita != NumCita && aux != NULL) {
		aux = aux->Sig;
	}
	if (aux == NULL) {
		MessageBox(hwnd, L"Cita no encontrada", L"Aviso", MB_ICONERROR);
		return;
	}

	//Llenar datos para editar (cambiar IDs).
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER1, DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&aux->fecha);
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER2, DTM_SETSYSTEMTIME, GDT_VALID, (LPARAM)&aux->hora);
	SendDlgItemMessage(hwnd, IDC_EDIT1, WM_SETTEXT, NULL, (LPARAM)aux->nombreCliente);
	SendDlgItemMessage(hwnd, IDC_EDIT2, WM_SETTEXT, NULL, (LPARAM)aux->telefono);
	SendDlgItemMessage(hwnd, IDC_COMBO1, CB_SETCURSEL, aux->especie, NULL);
	SendDlgItemMessage(hwnd, IDC_EDIT3, WM_SETTEXT, NULL, (LPARAM)aux->nombreMascota);
	SendDlgItemMessage(hwnd, IDC_EDIT4, WM_SETTEXT, NULL, (LPARAM)aux->motivo);
	SendDlgItemMessage(hwnd, IDC_EDIT5, WM_SETTEXT, NULL, (LPARAM)aux->costo);
	if (aux->estatus == 1) {
		CheckRadioButton(hwnd, IDC_RADIO1, IDC_RADIO3, IDC_RADIO1);
	}
	if (aux->estatus == 2) {
		CheckRadioButton(hwnd, IDC_RADIO1, IDC_RADIO3, IDC_RADIO2);
	}
	if (aux->estatus == 3) {
		CheckRadioButton(hwnd, IDC_RADIO1, IDC_RADIO3, IDC_RADIO3);
	}
}

//Usa ventana de agendar cita, se usa después de MostrarEditarCita().
void LeerEditarCita(nCita*& inicio, HWND hwnd, int NumCita) {
	//Buscar nodo.
	nCita* aux = inicio;
	if (inicio == NULL) {
		MessageBox(hwnd, L"La agenda esta vacia", L"Aviso", MB_ICONERROR);
		return;
	}
	while (aux->NumCita != NumCita && aux != NULL) {
		aux = aux->Sig;
	}
	if (aux == NULL) {
		MessageBox(hwnd, L"Cita no encontrada", L"Aviso", MB_ICONERROR);
		return;
	}

	//Handlers (cambiar IDs).
	HWND hFecha = GetDlgItem(hwnd, IDC_DATETIMEPICKER1);
	HWND hHora = GetDlgItem(hwnd, IDC_DATETIMEPICKER2);
	HWND hNameC = GetDlgItem(hwnd, IDC_EDIT1);
	HWND hTel = GetDlgItem(hwnd, IDC_EDIT2);
	HWND hEspecie = GetDlgItem(hwnd, IDC_COMBO1);
	HWND hNameM = GetDlgItem(hwnd, IDC_EDIT3);
	HWND hMotivo = GetDlgItem(hwnd, IDC_EDIT4);
	HWND hCosto = GetDlgItem(hwnd, IDC_EDIT5);

	//Auxiliares.
	int Length;

	//Guardar datos en nodo.
	//(Cambiar IDs de datetimepickers).
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER1, DTM_GETSYSTEMTIME, 0, (LPARAM)&aux->fecha);
	SendDlgItemMessage(hwnd, IDC_DATETIMEPICKER2, DTM_GETSYSTEMTIME, 0, (LPARAM)&aux->hora);

	Length = GetWindowTextLength(hFecha);
	GetWindowText(hFecha, aux->charfecha, ++Length);
	Length = GetWindowTextLength(hHora);
	GetWindowText(hHora, aux->charhora, ++Length);
	Length = GetWindowTextLength(hNameC);
	GetWindowText(hNameC, aux->nombreCliente, ++Length);
	Length = GetWindowTextLength(hTel);
	GetWindowText(hTel, aux->telefono, ++Length);

	//(Cambiar ID de combo box).
	aux->especie = SendDlgItemMessage(hwnd, IDC_COMBO1, CB_GETCURSEL, 0, 0);

	Length = GetWindowTextLength(hEspecie);
	GetWindowText(hEspecie, aux->charespecie, ++Length);
	Length = GetWindowTextLength(hNameM);
	GetWindowText(hNameM, aux->nombreMascota, ++Length);
	Length = GetWindowTextLength(hMotivo);
	GetWindowText(hMotivo, aux->motivo, ++Length);
	Length = GetWindowTextLength(hCosto);
	GetWindowText(hCosto, aux->costo, ++Length);

	//(Cambiar IDs de radios).
	if (IsDlgButtonChecked(hwnd, IDC_RADIO1) == BST_CHECKED) {
		aux->estatus = 1;
	}
	if (IsDlgButtonChecked(hwnd, IDC_RADIO2) == BST_CHECKED) {
		aux->estatus = 2;
	}
	if (IsDlgButtonChecked(hwnd, IDC_RADIO3) == BST_CHECKED) {
		aux->estatus = 3;
	}
}

//Usa ventana de agenda, llena la listbox.
//La listbox debe de tener ordenar en false para que funcione bien.
void ListBoxCitas(nCita*& inicio, HWND hwnd) {
	nCita* aux = inicio;
	if (inicio == NULL) {
		return;
	}

	//Imprimir cada nodo en la listbox.
	int pos = 0;
	while (aux != NULL) {
		wchar_t item[100];
		wcscpy_s(item, aux->charfecha);
		wcscat_s(item, L" - ");
		wcscat_s(item, aux->nombreCliente);
		if (aux->estatus == 1) {
			wcscat_s(item, L"   (Pendiente)");
		}
		if (aux->estatus == 2) {
			wcscat_s(item, L"   (Cancelada)");
		}
		if (aux->estatus == 3) {
			wcscat_s(item, L"   (Efectuada)");
		}
		
		//(Cambiar IDs de Listbox).
		SendDlgItemMessage(hwnd, IDC_LIST1, LB_ADDSTRING, NULL, (LPARAM)item);
		SendDlgItemMessage(hwnd, IDC_LIST1, LB_SETITEMDATA, pos, (LPARAM)aux->NumCita);	//Se le añade numero de cita como info a cada nombre.
		aux = aux->Sig;
		pos++;
	}
}

//Usa ventana de agenda, llena el editcontrol de vista previa.
void VistaPreviaCita(nCita*& inicio, HWND hwnd, int NumCita) {
	//Buscar nodo.
	nCita* aux = inicio;
	if (inicio == NULL) {
		return;
	}
	while (aux->NumCita != NumCita && aux != NULL) {
		aux = aux->Sig;
	}
	if (aux == NULL) {
		return;
	}


	//Auxiliares.
	wchar_t vprev[600];

	//Concatenar mensaje con los datos.
	wcscpy_s(vprev, L"Fecha: ");
	wcscat_s(vprev, aux->charfecha);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Hora: ");
	wcscat_s(vprev, aux->charhora);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Estatus: ");
	if (aux->estatus == 1) {
		wcscat_s(vprev, L"Pendiente");
	}
	if (aux->estatus == 2) {
		wcscat_s(vprev, L"Cancelada");
	}
	if (aux->estatus == 3) {
		wcscat_s(vprev, L"Efectuada");
	}
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Cliente: ");
	wcscat_s(vprev, aux->nombreCliente);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Telefono: ");
	wcscat_s(vprev, aux->telefono);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Mascota: ");
	wcscat_s(vprev, aux->nombreMascota);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Especie: ");
	wcscat_s(vprev, aux->charespecie);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Motivo: ");
	wcscat_s(vprev, aux->motivo);
	wcscat_s(vprev, L", ");
	wcscat_s(vprev, L"Costo: ");
	wcscat_s(vprev, aux->costo);

	//Imprimir vista previa en edit control.
	SendDlgItemMessage(hwnd, IDC_PREV, WM_SETTEXT, NULL, (LPARAM)vprev);
}

//Usa la ventana de agenda.
void EliminarCita(nCita*& inicio, HWND hwnd, int NumCita) {
	//Buscar nodo.
	nCita* aux = inicio;
	if (inicio == NULL) {
		MessageBox(hwnd, L"La agenda esta vacia", L"Aviso", MB_ICONERROR);
		return;
	}
	while (aux->NumCita != NumCita && aux != NULL) {
		aux = aux->Sig;
	}
	if (aux == NULL) {
		MessageBox(hwnd, L"Cita no encontrada", L"Aviso", MB_ICONERROR);
		return;
	}

	//Revisar si se va a eliminar el primer nodo.
	if (aux == inicio) {
		inicio = aux->Sig;
	}
	else if (aux->Sig == NULL) {
		nCita* auxant = aux->Ant;
		auxant->Sig = NULL;
	}
	else {
		//Crear auxiliares.
		nCita* auxsig = aux->Sig;
		nCita* auxant = aux->Ant;

		//Conectar auxiliares.
		auxsig->Ant = auxant;
		auxant->Sig = auxsig;
	}

	//Borrar nodo.
	delete aux;
}


//Esta función pone los datos del doctor que esten guardados en las editbox de la ventana de información.
void ImprimirDoctor(HWND hwnd) {
	//Imprimir datos en editboxes(Cambiar IDs).
	SendDlgItemMessage(hwnd, IDC_USERNAME, WM_SETTEXT, NULL, (LPARAM)nDoctor);
	SendDlgItemMessage(hwnd, IDC_CEDULA, WM_SETTEXT, NULL, (LPARAM)cDoctor);
	SendDlgItemMessage(hwnd, IDC_CLAVE, WM_SETTEXT, NULL, (LPARAM)cUsuario);
	SendDlgItemMessage(hwnd, IDC_PASSWORD, WM_SETTEXT, NULL, (LPARAM)pass);
}

//Esta función lee los datos de los editbox y los guarda. Puede usarse para "Guardar Cambios". 
void LeerDoctor(HWND hwnd) {
	//Handlers(Cambiar IDs).
	HWND hName = GetDlgItem(hwnd, IDC_USERNAME);
	HWND hCedula = GetDlgItem(hwnd, IDC_CEDULA);
	HWND hClave = GetDlgItem(hwnd, IDC_CLAVE);
	HWND hPassword = GetDlgItem(hwnd, IDC_PASSWORD);

	//Auxiliar.
	int Length;

	//Leer y guardar datos.
	Length = GetWindowTextLength(hName);
	GetWindowText(hName, nDoctor, ++Length);
	Length = GetWindowTextLength(hCedula);
	GetWindowText(hCedula, cDoctor, ++Length);
	Length = GetWindowTextLength(hClave);
	GetWindowText(hClave, cUsuario, ++Length);
	Length = GetWindowTextLength(hPassword);
	GetWindowText(hPassword, pass, ++Length);

	//Notificación.
	MessageBox(hwnd, L"Datos guardados", L"Aviso", MB_OK);
}

//Esta funcion se usa en la pantalla de Iniciar Sesion.
void IniciarSesion(HWND hwnd) {
	//Handlers.
	HWND hClave = GetDlgItem(hwnd, IDC_LOGINCLAVE);
	HWND hPassword = GetDlgItem(hwnd, IDC_LOGINPASSWORD);

	//Auxiliares.
	int Length;
	wchar_t loginclave[100] = { L"" }, loginpassword[100] = { L"" };

	//Leer datos introducidos.
	Length = GetWindowTextLength(hClave);
	GetWindowText(hClave, loginclave, ++Length);
	Length = GetWindowTextLength(hPassword);
	GetWindowText(hPassword, loginpassword, ++Length);

	
	//Comprobar datos.
	if(wcscmp(loginclave, cUsuario) == 0 && wcscmp(loginpassword, pass) == 0) {
		login = TRUE;
	}
}

//Guardar archivo binario de lista ligada de citas.
void ArchivoCitas(char* archivo) {
	ofstream file;
	file.open(archivo, ios::trunc | ios::binary);
	if (file.is_open())
	{
		nCita* aux = inicio;
		while (aux != NULL)
		{
			file.write((char*)aux, sizeof(nCita));

			aux = aux->Sig;
		}
		file.close();
	}
}

//Leer archivo binario de lista ligada de citas.
void readCitas(char* archivo) {
	nCita* aux = 0;
	nCita* ultimo = 0;
	nCita* nuevo = 0;
	ifstream file;
	file.open(archivo, ios::binary);
	if (file.is_open())
	{
		nuevo = new nCita;
		file.read((char*)nuevo, sizeof(nCita));
		while (!file.eof())
		{
			aux = new nCita;
			aux = nuevo;

			aux->Ant = 0;
			aux->Sig = 0;
			if (inicio == 0) {
				inicio = aux;
			}
			else {
				ultimo->Sig = aux;
				aux->Ant = ultimo;
			}
			ultimo = aux;

			nuevo = new nCita;
			file.read((char*)nuevo, sizeof(nCita));
		}
		file.close();
	}
}
